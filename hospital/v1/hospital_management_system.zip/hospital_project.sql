-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 02:44 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_users2`
--

CREATE TABLE `all_users2` (
  `user_id` int(11) NOT NULL,
  `uemp_id` int(11) DEFAULT NULL,
  `upatient_id` int(11) DEFAULT NULL,
  `user_first_name` varchar(30) NOT NULL,
  `user_last_name` varchar(30) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_users2`
--

INSERT INTO `all_users2` (`user_id`, `uemp_id`, `upatient_id`, `user_first_name`, `user_last_name`, `user_email`, `user_pass`, `user_type`) VALUES
(1, 1, NULL, 'Anik', 'Sarker', 'anik@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'Admin'),
(2, 2, NULL, 'George', 'Clooney', 'george@email.com', 'a152e841783914146e4bcd4f39100686', 'Doctor'),
(3, 3, NULL, 'Dwayne', 'Johnson', 'dwayne@email.com', '912ec803b2ce49e4a541068d495ab570', 'Doctor'),
(4, 4, NULL, 'Roger', 'Waters', 'roger@email.com', '912ec803b2ce49e4a541068d495ab570', 'Doctor'),
(5, NULL, 1, 'Jaiden', 'Marks', 'marks@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(6, NULL, 2, 'Matt', 'Ryan', 'ryan@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(7, NULL, 3, 'Lanita', 'Nelson', 'lanita@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(8, NULL, 4, 'Hope', 'Chapman', 'hope@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(25, NULL, 21, 'Lionel', 'Messi', 'messi@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(35, NULL, 33, 'Luke', 'Bryan', 'bryan@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(36, NULL, 34, 'Bruno', 'Mars', 'mars@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(37, NULL, 36, 'Taylor', 'Swift', 'swift@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(38, NULL, 37, 'Aditi', 'Thakur', 'aditi@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(39, NULL, 38, 'Arif', 'Mamud', 'arif@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(40, NULL, 39, 'Anoop', 'Sen', 'anoop@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(41, NULL, 40, 'Asok', 'Mandal', 'asok@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient'),
(42, NULL, 41, 'Imam', 'Azam', 'azam@email.com', '912ec803b2ce49e4a541068d495ab570', 'Patient');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoint_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appoint_date` date NOT NULL,
  `time` varchar(30) DEFAULT NULL,
  `is_checked` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoint_id`, `emp_id`, `patient_id`, `appoint_date`, `time`, `is_checked`) VALUES
(1, 3, 34, '2018-12-19', '9.3am', 'checked'),
(2, 2, 21, '2018-12-19', '15:00', 'checked'),
(3, 3, 3, '2018-12-19', '18:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(40) NOT NULL,
  `dept_description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `dept_name`, `dept_description`) VALUES
(1, 'Microbiology', 'The microbiology department looks at all aspects of microbiology, such as bacterial and viral infections.'),
(2, 'Neurology', 'This unit deals with disorders of the nervous system, including the brain and spinal cord. It\'s run by doctors who specialise in this area (neurologists) and their staff.'),
(3, 'Nutrition and dietetics', 'Trained dieticians and nutritionists provide specialist advice on diet for hospital wards and outpatient clinics, forming part of a multidisciplinary team.'),
(4, 'Cardiology', 'This department provides medical care to patients who have problems with their heart or circulation. It treats people on an inpatient and outpatient basis.\r\nelectrocardiogram (ECG) and exercise tests to measure heart function, echocardiograms (ultrasound scan of the heart), scans of the carotid artery in your neck to determine stroke risk, 24-hour blood pressure tests, insertion of pacemakers, cardiac catheterisation (coronary angiography) to see if there are any blocks in your arteries'),
(5, 'Accident and emergen', 'This department sometimes called Casualty is where you are likely to be taken if you have called an ambulance in an emergency.'),
(6, 'Anaesthetics', 'Doctors in this department give anaesthetic for operations.'),
(7, 'General surgery', 'The general surgery ward covers a wide range of surgery and includes: 			day surgery 			thyroid surgery 			kidney transplants 			colon surgery 			laparoscopic cholecystectomy (gallbladder removal) 			endoscopy 			breast surgery.'),
(8, 'Gynaecology', 'These departments investigate and treat problems of the female urinary tract and reproductive organs, such as endometritis, infertility and incontinence.'),
(9, 'Administration', 'Management is the administration of an organization, whether it is a business, a not-for-profit organization, or government body.'),
(10, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(35) NOT NULL,
  `age` int(11) NOT NULL,
  `date_of_birth` varchar(40) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `contact_no` int(20) NOT NULL,
  `salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `dep_id`, `first_name`, `last_name`, `email`, `pass`, `age`, `date_of_birth`, `gender`, `user_type`, `contact_no`, `salary`) VALUES
(1, 9, 'Anik', 'Sarker', 'anik@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 24, '1994-November-6', 'male', 'Admin', 1898798985, 40000),
(2, 2, 'George', 'Clooney', 'george@email.com', 'a152e841783914146e4bcd4f39100686', 15, '2003-April-13', 'male', 'Doctor', 186465466, 45000),
(3, 4, 'Dwayne', 'Johnson', 'dwayne@email.com', '912ec803b2ce49e4a541068d495ab570', 15, '2003-April-17', 'male', 'Doctor', 2147483647, 50000),
(4, 4, 'Roger', 'Waters', 'roger@email.com', '912ec803b2ce49e4a541068d495ab570', 27, '1991-June-18', 'male', 'Doctor', 1956465448, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `ot_schedules`
--

CREATE TABLE `ot_schedules` (
  `ot_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(40) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `ot_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ot_schedules`
--

INSERT INTO `ot_schedules` (`ot_id`, `emp_id`, `emp_name`, `date`, `time`, `ot_type`) VALUES
(1, 2, 'George Clooney', '2018-12-19', '10:30:00', 'Kidney Transplant');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `date_of_birth` varchar(40) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `contact_no` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `first_name`, `last_name`, `email`, `pass`, `age`, `date_of_birth`, `gender`, `user_type`, `contact_no`) VALUES
(1, 'Jaiden', 'Marks', 'marks@email.com', '912ec803b2ce49e4a541068d495ab570', 17, '2001-May-11', 'male', 'Patient', 234234234),
(2, 'Matt', 'Ryan', 'ryan@email.com', '912ec803b2ce49e4a541068d495ab570', 25, '1993-March-14', 'male', 'Patient', 2147483647),
(3, 'Lanita', 'Nelson', 'lanita@email.com', '912ec803b2ce49e4a541068d495ab570', 11, '2007-June-30', 'female', 'Patient', 234234234),
(4, 'Hope', 'Chapman', 'hope@email.com', '912ec803b2ce49e4a541068d495ab570', 12, '2006-August-12', 'female', 'Patient', 2147483647),
(21, 'Lionel', 'Messi', 'messi@email.com', '912ec803b2ce49e4a541068d495ab570', 12, '2006-August-15', 'male', 'Patient', 123123123),
(33, 'Luke', 'Bryan', 'bryan@email.com', '912ec803b2ce49e4a541068d495ab570', 11, '2007-May-13', 'male', 'Patient', 2147483647),
(34, 'Bruno', 'Mars', 'mars@email.com', '912ec803b2ce49e4a541068d495ab570', 12, '2006-August-29', 'male', 'Patient', 323232323),
(36, 'Taylor', 'Swift', 'swift@email.com', '912ec803b2ce49e4a541068d495ab570', 22, '1996-July-12', 'female', 'Patient', 213465897),
(37, 'Aditi', 'Thakur', 'aditi@email.com', '912ec803b2ce49e4a541068d495ab570', 23, '1995-April-13', 'female', 'Patient', 1235468987),
(38, 'Arif', 'Mamud', 'arif@email.com', '912ec803b2ce49e4a541068d495ab570', 14, '2004-September-15', 'male', 'Patient', 123123345),
(39, 'Anoop', 'Sen', 'anoop@email.com', '912ec803b2ce49e4a541068d495ab570', 7, '2011-August-30', 'male', 'Patient', 234234234),
(40, 'Asok', 'Mandal', 'asok@email.com', '912ec803b2ce49e4a541068d495ab570', 16, '2002-December-17', 'male', 'Patient', 2147483647),
(41, 'Imam', 'Azam', 'azam@email.com', '912ec803b2ce49e4a541068d495ab570', 25, '1993-September-28', 'male', 'Patient', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `patient_admitted`
--

CREATE TABLE `patient_admitted` (
  `reg_id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `room_id` int(12) NOT NULL,
  `admit_date` varchar(30) NOT NULL,
  `release_date` varchar(30) NOT NULL,
  `room_no` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_admitted`
--

INSERT INTO `patient_admitted` (`reg_id`, `application_id`, `dep_id`, `emp_id`, `patient_id`, `room_id`, `admit_date`, `release_date`, `room_no`) VALUES
(3, 4, 4, 3, 1, 12, '2018-12-01', '2018-12-06', 401);

-- --------------------------------------------------------

--
-- Table structure for table `patient_application`
--

CREATE TABLE `patient_application` (
  `patient_app_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `problem` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_application`
--

INSERT INTO `patient_application` (`patient_app_id`, `patient_id`, `department`, `problem`) VALUES
(4, 1, 'Cardiology', 'Open Heart Surgery');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `prescrip_id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `pat_id` int(11) NOT NULL,
  `prescrip_date` varchar(50) NOT NULL,
  `disease` varchar(100) NOT NULL,
  `tests` varchar(255) NOT NULL,
  `medicine` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`prescrip_id`, `doc_id`, `pat_id`, `prescrip_date`, `disease`, `tests`, `medicine`, `comment`) VALUES
(1, 2, 41, '2017-January-02', 'Chest pain', 'MRI, CGI, X-ray, Blood test, Biopsy, Endoscopy, Imaging', 'Napa, Ace plus, Max pro, Parachitamol, Aspirin', 'Nothing serious'),
(2, 2, 1, '2018-12-18', 'asdf', 'asdf', 'asdf', 'asdf');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `type_id`, `location`) VALUES
(12, 1, '401'),
(13, 3, '403'),
(14, 2, '402'),
(15, 2, '111');

-- --------------------------------------------------------

--
-- Table structure for table `room_type`
--

CREATE TABLE `room_type` (
  `type_id` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `cost` int(11) NOT NULL,
  `max_capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_type`
--

INSERT INTO `room_type` (`type_id`, `type`, `cost`, `max_capacity`) VALUES
(1, 'Suite', 1000, 1),
(2, 'Delux', 500, 2),
(3, 'Private', 700, 1),
(4, 'General Ward', 100, 12),
(5, 'special', 111, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_users2`
--
ALTER TABLE `all_users2`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `alluser_fk_patient_id` (`upatient_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoint_id`),
  ADD KEY `appointment_fk_employee` (`emp_id`),
  ADD KEY `appointment_fk_patients` (`patient_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`),
  ADD UNIQUE KEY `name` (`dept_name`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `employee_fk_dep` (`dep_id`);

--
-- Indexes for table `ot_schedules`
--
ALTER TABLE `ot_schedules`
  ADD PRIMARY KEY (`ot_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `patient_admitted`
--
ALTER TABLE `patient_admitted`
  ADD PRIMARY KEY (`reg_id`),
  ADD UNIQUE KEY `patient_id` (`patient_id`);

--
-- Indexes for table `patient_application`
--
ALTER TABLE `patient_application`
  ADD PRIMARY KEY (`patient_app_id`),
  ADD UNIQUE KEY `patient_id` (`patient_id`),
  ADD KEY `patient_app_fk_patient` (`patient_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`prescrip_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`),
  ADD UNIQUE KEY `location` (`location`),
  ADD KEY `room_fk_room_type` (`type_id`);

--
-- Indexes for table `room_type`
--
ALTER TABLE `room_type`
  ADD PRIMARY KEY (`type_id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_users2`
--
ALTER TABLE `all_users2`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ot_schedules`
--
ALTER TABLE `ot_schedules`
  MODIFY `ot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `patient_admitted`
--
ALTER TABLE `patient_admitted`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `patient_application`
--
ALTER TABLE `patient_application`
  MODIFY `patient_app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `prescrip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `room_type`
--
ALTER TABLE `room_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_fk_employee` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  ADD CONSTRAINT `appointment_fk_patients` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_fk_dep` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dept_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `patient_application`
--
ALTER TABLE `patient_application`
  ADD CONSTRAINT `patient_app_fk_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_fk_room_type` FOREIGN KEY (`type_id`) REFERENCES `room_type` (`type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
