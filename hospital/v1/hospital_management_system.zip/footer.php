
<footer class=" navbar-inverse" id="footer" >
    <div class="container">
        <div class="row">
            <div class="col-xs-4">
                <div class="col-xs-4" id="left">
                    <h5><span class="glyphicon glyphicon-earphone"></span> Hotlines: 0148978778</h5>
                </div>
            </div>

            <div class="col-xs-4">
                <div class="col-xs-4" id="left">
                    <h5> <span class="glyphicon glyphicon-envelope"></span> Email: hospital@email.com</h5>
                </div>
            </div>

        </div>
        <div>
            <div>
                <p>Copyright © 2018 Untitled Hospitals Ltd.</p>
            </div>
        </div>
    </div>
</footer>