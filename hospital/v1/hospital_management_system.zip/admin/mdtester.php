<?php 

	echo "asdf =+> " .md5("asdf");
	echo "<br> admin =+> " .md5("admin");

	echo " ";

 ?>


    "<br>asdfasdasdfasdf <?= 8+9 ?>"
    "<br>pppppppppppp"<?= 8+9 ?>