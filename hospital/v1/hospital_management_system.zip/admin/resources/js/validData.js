function validData(){
	var fName = document.getElementById('firstname').value;
	var lName = document.getElementById('lastname').value;
	
	alert(fName + " " + lName);
	console.log(fName + lName);

}