-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2018 at 04:27 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_users`
--

CREATE TABLE `all_users` (
  `user_id` int(11) NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `user_first_name` varchar(30) NOT NULL,
  `user_last_name` varchar(30) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_users`
--

INSERT INTO `all_users` (`user_id`, `emp_id`, `patient_id`, `user_first_name`, `user_last_name`, `user_email`, `user_password`, `user_type`) VALUES
(1, 1, NULL, 'Anik', 'Sarker', 'anik@gmail.com', 'asdf', 'Admin'),
(2, 2, NULL, 'George', 'Clooney', 'george@email.com', 'asdf', 'Doctor'),
(3, 3, NULL, 'Dwayne', 'Johnson', 'dwayne@email.com', 'asdf', 'Doctor'),
(4, 4, NULL, 'Roger', 'Waters', 'roger@email.com', 'asdf', 'Doctor');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoint_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `time` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(40) NOT NULL,
  `dept_description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `dept_name`, `dept_description`) VALUES
(1, 'Microbiology', 'The microbiology department looks at all aspects of microbiology, such as bacterial and viral infections.'),
(2, 'Neurology', 'This unit deals with disorders of the nervous system, including the brain and spinal cord. It\'s run by doctors who specialise in this area (neurologists) and their staff.'),
(3, 'Nutrition and dietetics', 'Trained dieticians and nutritionists provide specialist advice on diet for hospital wards and outpatient clinics, forming part of a multidisciplinary team.'),
(4, 'Cardiology', 'This department provides medical care to patients who have problems with their heart or circulation. It treats people on an inpatient and outpatient basis.\r\nelectrocardiogram (ECG) and exercise tests to measure heart function, echocardiograms (ultrasound scan of the heart), scans of the carotid artery in your neck to determine stroke risk, 24-hour blood pressure tests, insertion of pacemakers, cardiac catheterisation (coronary angiography) to see if there are any blocks in your arteries'),
(5, 'Accident and emergen', 'This department sometimes called Casualty is where you are likely to be taken if you have called an ambulance in an emergency.'),
(6, 'Anaesthetics', 'Doctors in this department give anaesthetic for operations.'),
(7, 'General surgery', 'The general surgery ward covers a wide range of surgery and includes: 			day surgery 			thyroid surgery 			kidney transplants 			colon surgery 			laparoscopic cholecystectomy (gallbladder removal) 			endoscopy 			breast surgery.'),
(8, 'Gynaecology', 'These departments investigate and treat problems of the female urinary tract and reproductive organs, such as endometritis, infertility and incontinence.'),
(9, 'Administration', 'Management is the administration of an organization, whether it is a business, a not-for-profit organization, or government body.');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(25) NOT NULL,
  `age` int(11) NOT NULL,
  `date_of_birth` varchar(40) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `contact_no` int(20) NOT NULL,
  `salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `dep_id`, `first_name`, `last_name`, `email`, `pass`, `age`, `date_of_birth`, `gender`, `user_type`, `contact_no`, `salary`) VALUES
(1, 9, 'Anik', 'Sarker', 'anik@gmail.com', 'asdf', 24, '1994-11-6', 'Male', 'Admin', 1898798985, 40000),
(2, 2, 'George', 'Clooney', 'george@email.com', 'asdf', 15, '2003-April-13', 'male', 'Doctor', 186465466, 45000),
(3, 4, 'Dwayne', 'Johnson', 'dwayne@email.com', 'asdf', 15, '2003-April-17', 'male', 'Doctor', 2147483647, 50000),
(4, 4, 'Roger', 'Waters', 'roger@email.com', 'asdf', 27, '1991-June-18', 'male', 'Doctor', 1956465448, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `date_of_birth` varchar(40) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `contact_no` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `first_name`, `last_name`, `email`, `pass`, `age`, `date_of_birth`, `gender`, `user_type`, `contact_no`) VALUES
(1, 'Jaiden', 'Marks', 'Marks@email.com', 'asdf', 17, '2001-May-11', 'male', 'Patient', 234234234);

-- --------------------------------------------------------

--
-- Table structure for table `patient_admitted`
--

CREATE TABLE `patient_admitted` (
  `reg_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `room_type_id` int(12) NOT NULL,
  `admit_date` varchar(30) NOT NULL,
  `release_date` varchar(30) NOT NULL,
  `room_no` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient_application`
--

CREATE TABLE `patient_application` (
  `patient_app_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `problem` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_application`
--

INSERT INTO `patient_application` (`patient_app_id`, `patient_id`, `department`, `problem`) VALUES
(4, 1, 'Cardiology', 'Open Heart Surgery');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `type_id`, `location`) VALUES
(12, 1, '401'),
(13, 3, '403'),
(14, 2, '402');

-- --------------------------------------------------------

--
-- Table structure for table `room_type`
--

CREATE TABLE `room_type` (
  `type_id` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `cost` int(11) NOT NULL,
  `max_capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_type`
--

INSERT INTO `room_type` (`type_id`, `type`, `cost`, `max_capacity`) VALUES
(1, 'Suite', 1000, 1),
(2, 'Delux', 500, 2),
(3, 'Private', 700, 1),
(4, 'General Ward', 100, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_users`
--
ALTER TABLE `all_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD KEY `alluser_fk_emp_id` (`emp_id`),
  ADD KEY `alluser_fk_patient_id` (`patient_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoint_id`),
  ADD KEY `appointment_fk_employee` (`emp_id`),
  ADD KEY `appointment_fk_patients` (`patient_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`),
  ADD UNIQUE KEY `name` (`dept_name`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `employee_fk_dep` (`dep_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `patient_admitted`
--
ALTER TABLE `patient_admitted`
  ADD PRIMARY KEY (`reg_id`),
  ADD KEY `patient_register_fk_department` (`dep_id`),
  ADD KEY `patient_register_fk_employee` (`emp_id`),
  ADD KEY `patient_register_fk_patient` (`patient_id`),
  ADD KEY `room_type_id` (`room_type_id`),
  ADD KEY `room_type_id_2` (`room_type_id`);

--
-- Indexes for table `patient_application`
--
ALTER TABLE `patient_application`
  ADD PRIMARY KEY (`patient_app_id`),
  ADD KEY `patient_app_fk_patient` (`patient_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `room_fk_room_type` (`type_id`);

--
-- Indexes for table `room_type`
--
ALTER TABLE `room_type`
  ADD PRIMARY KEY (`type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoint_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient_admitted`
--
ALTER TABLE `patient_admitted`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient_application`
--
ALTER TABLE `patient_application`
  MODIFY `patient_app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `room_type`
--
ALTER TABLE `room_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `all_users`
--
ALTER TABLE `all_users`
  ADD CONSTRAINT `alluser_fk_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `alluser_fk_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_fk_employee` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  ADD CONSTRAINT `appointment_fk_patients` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_fk_dep` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dept_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `patient_admitted`
--
ALTER TABLE `patient_admitted`
  ADD CONSTRAINT `patient_register_fk_department` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dept_id`),
  ADD CONSTRAINT `patient_register_fk_employee` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  ADD CONSTRAINT `patient_register_fk_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  ADD CONSTRAINT `patient_register_fk_room_type` FOREIGN KEY (`room_type_id`) REFERENCES `room_type` (`type_id`);

--
-- Constraints for table `patient_application`
--
ALTER TABLE `patient_application`
  ADD CONSTRAINT `patient_app_fk_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_fk_room_type` FOREIGN KEY (`type_id`) REFERENCES `room_type` (`type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
